Her kan du legge til globale styled components, themes etc
Du kan også legge til .scss filer her om du vil bruke det isteden
