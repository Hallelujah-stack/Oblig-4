Her lager du alle komponentene dine. Eks Movies, Movie. De igjen kan du bruke inne på sidene (pages)
