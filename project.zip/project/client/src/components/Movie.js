import React from 'react'

const Movie = ({ title, actor }) => {
    return (
<section>
<p>{title} {actor}</p>
 </section>
  );
};
export default Movie;
