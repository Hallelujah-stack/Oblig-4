Her setter du opp navigasjonen din
Ref. React Router
