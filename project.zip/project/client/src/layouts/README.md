Her kan du legge til all layout du skal bruke. Eks. om noe skal være fullskjerm vs sentrert
