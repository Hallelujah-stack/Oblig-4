/**
 * Home bruker nå komponenten jeg har laget og sender en prop
 */
import Movies from '../components/Movies';
const Home = () => (
  <section>
    <h1>Home</h1>;
    <Movies />
</section>
);

export default Home;
