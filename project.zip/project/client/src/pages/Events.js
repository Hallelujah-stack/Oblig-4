import { useState } from "react";
import { getEvents } from '../utils/yourService';

const Events = () => {
    const [events, setEvents] = useState([])

    const handleClick = async() => {
        const data = await getEvents();
        setEvents(data);
    }
    return(
        <div>
            {data? length > 0 ? <p>{JSON.stringify(data[0].title)}</p> : null }
            <button type = "button" onClick = {handleClick}>Button</button>
        </div>
    )
}
export default Events;