// Do not edit this
module.exports = {
  styledComponents: {
    ssr: true,
    displayName: true,
    preprocess: false,
  },
};
